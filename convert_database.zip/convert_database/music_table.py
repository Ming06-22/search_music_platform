import json
import sqlite3

with open("music.json", "r", encoding = "utf-8") as file:
    datas = json.load(file)

title = []
time = []
location = []
locationName = []
onSales = []
price = []
latitude = []
longitude = []
endTime = []
music_list = [title, time, location, locationName, onSales, price, latitude, longitude, endTime]

for data in datas:
    for info in data["showInfo"]:
        title.append(data["title"])
        time.append(info["time"])
        location.append(info["location"])
        locationName.append(info["locationName"])
        onSales.append(info["onSales"])
        price.append(info["price"])
        latitude.append(info["latitude"])
        longitude.append(info["longitude"])
        endTime.append(info["endTime"])

db = sqlite3.connect("info.db")

sql = '''Create table music(
        title TEXT,
        time TEXT,
        location TEXT,
        locationName TEXT,
        onSales TEXT,
        price TEXT,
        latitude TEXT,
        longitude TEXT,
        endTime TEXT)'''
db.execute(sql)
sql = '''insert into music(title, time, location, locationName, onSales, price, latitude, longitude, endTime) values(?,?,?,?,?,?,?,?,?)'''
for i in range(len(music_list[0])):
    title = music_list[0][i]
    time = music_list[1][i]
    location = music_list[2][i]
    locationName = music_list[3][i]
    onSales = music_list[4][i]
    price = music_list[5][i]
    latitude = music_list[6][i]
    longitude = music_list[7][i]
    endTime = music_list[8][i]
    insert_info = (title, time, location, locationName, onSales, price, latitude, longitude, endTime)
    db.execute(sql, insert_info)
    db.commit()
db.close()