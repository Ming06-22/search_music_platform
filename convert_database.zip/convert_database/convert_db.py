import json
import sqlite3

with open("independent_music.json", "r", encoding = "utf-8") as file:
    datas1 = json.load(file)
with open("music.json", "r", encoding = "utf-8") as file:
    datas2 = json.load(file)
with open("Covid19.json", "r", encoding = "utf-8") as file:
    datas3 = json.load(file)

time1 = []
location1 = []
locationName1 = []
onSales1 = []
price1 = []
latitude1 = []
longitude1 = []
endTime1 = []
independent_music_list = [time1, location1, locationName1, onSales1, price1, latitude1, longitude1, endTime1]

time2 = []
location2 = []
locationName2 = []
onSales2 = []
price2 = []
latitude2 = []
longitude2 = []
endTime2 = []
music_list = [time2, location2, locationName2, onSales2, price2, latitude2, longitude2, endTime2]

確定病名3 = []
個案研判日3 = []
縣市3 = []
鄉鎮3 = []
性別3 = []
是否為境外移入3 = []
年齡層3 = []
確定病例數3 = []
covid_list = [確定病名3, 個案研判日3, 縣市3, 鄉鎮3, 性別3, 是否為境外移入3, 年齡層3, 確定病例數3]

for data in datas1:
    for info in data["showInfo"]:
        time1.append(info["time"])
        location1.append(info["location"])
        locationName1.append(info["locationName"])
        onSales1.append(info["onSales"])
        price1.append(info["price"])
        latitude1.append(info["latitude"])
        longitude1.append(info["longitude"])
        endTime1.append(info["endTime"])
print(time1)

for data in datas2:
    for info in data["showInfo"]:
        time2.append(info["time"])
        location2.append(info["location"])
        locationName2.append(info["locationName"])
        onSales2.append(info["onSales"])
        price2.append(info["price"])
        latitude2.append(info["latitude"])
        longitude2.append(info["longitude"])
        endTime2.append(info["endTime"])

for data in datas3:
    確定病名3.append(data["確定病名"])
    個案研判日3.append(data["個案研判日"])
    縣市3.append(data["縣市"])
    鄉鎮3.append(data["鄉鎮"])
    性別3.append(data["性別"])
    是否為境外移入3.append(data["是否為境外移入"])
    年齡層3.append(data["年齡層"])
    確定病例數3.append(data["確定病例數"])

db = sqlite3.connect("info.db")

sql = '''Create table independent_music(
        time TEXT,
        location TEXT,
        locationName TEXT,
        onSales TEXT,
        price TEXT,
        latitude TEXT,
        longitude TEXT,
        endTime TEXT)'''
db.execute(sql)
sql = '''Create table music(
        time TEXT,
        location TEXT,
        locationName TEXT,
        onSales TEXT,
        price TEXT,
        latitude TEXT,
        longitude TEXT,
        endTime TEXT)'''
db.execute(sql)
sql = '''Create table covid(
        確定病名 TEXT,
        個案研判日 TEXT,
        縣市 TEXT,
        鄉鎮 TEXT,
        性別 TEXT,
        是否為境外移入 TEXT,
        年齡層 TEXT,
        確定病例數 TEXT)'''
db.execute(sql)

sql = '''insert into independent_music(time, location, locationName, onSales, price, latitude, longitude, endTime) values(?,?,?,?,?,?,?,?)'''
for i in range(len(independent_music_list[0])):
    time = independent_music_list[0][i]
    location = independent_music_list[1][i]
    locationName = independent_music_list[2][i]
    onSales = independent_music_list[3][i]
    price = independent_music_list[4][i]
    latitude = independent_music_list[5][i]
    longitude = independent_music_list[6][i]
    endTime = independent_music_list[7][i]
    insert_info = (time, location, locationName, onSales, price, latitude, longitude, endTime)
    db.execute(sql, insert_info)
    db.commit()
sql = '''insert into music(time, location, locationName, onSales, price, latitude, longitude, endTime) values(?,?,?,?,?,?,?,?)'''
for i in range(len(music_list[0])):
    time = music_list[0][i]
    location = music_list[1][i]
    locationName = music_list[2][i]
    onSales = music_list[3][i]
    price = music_list[4][i]
    latitude = music_list[5][i]
    longitude = music_list[6][i]
    endTime = music_list[7][i]
    insert_info = (time, location, locationName, onSales, price, latitude, longitude, endTime)
    db.execute(sql, insert_info)
    db.commit()
sql = '''insert into covid(確定病名, 個案研判日, 縣市, 鄉鎮, 性別, 是否為境外移入, 年齡層, 確定病例數) values(?,?,?,?,?,?,?,?)'''
for i in range(len(covid_list[0])):
    確定病名 = covid_list[0][i]
    個案研判日 = covid_list[1][i]
    縣市 = covid_list[2][i]
    鄉鎮 = covid_list[3][i]
    性別 = covid_list[4][i]
    是否為境外移入 = covid_list[5][i]
    年齡層 = covid_list[6][i]
    確定病例數 = covid_list[7][i]
    insert_info = (確定病名, 個案研判日, 縣市, 鄉鎮, 性別, 是否為境外移入, 年齡層, 確定病例數)
    db.execute(sql, insert_info)
    db.commit()
db.close()