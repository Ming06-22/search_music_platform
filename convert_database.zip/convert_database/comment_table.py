import sqlite3

db = sqlite3.connect("info.db")
sql = '''Create table message_db(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        email TEXT,
        message TEXT)'''
db.execute(sql)
db.close()